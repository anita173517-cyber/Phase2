.class public final Lc1/k;
.super Ljava/lang/Thread;
.source "SourceFile"


# instance fields
.field public final synthetic k:Lc1/l;


# direct methods
.method public constructor <init>(Lc1/l;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lc1/k;->k:Lc1/l;

    .line 2
    .line 3
    const-string p1, "ExoPlayer:SimpleDecoder"

    .line 4
    .line 5
    invoke-direct {p0, p1}, Ljava/lang/Thread;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 1
    iget-object v0, p0, Lc1/k;->k:Lc1/l;

    .line 2
    .line 3
    invoke-static {v0}, Lc1/l;->access$000(Lc1/l;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method
