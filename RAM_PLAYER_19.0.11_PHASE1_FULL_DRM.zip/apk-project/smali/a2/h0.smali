.class public interface abstract La2/h0;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract c()Z
.end method

.method public abstract d()Z
.end method

.method public abstract e(J)La2/g0;
.end method

.method public abstract g()J
.end method
