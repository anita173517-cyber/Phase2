.class public final Lc/p;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/p;
.implements Lc/a;


# instance fields
.field public final k:Landroidx/lifecycle/t;

.field public final l:Lr0/k;

.field public m:Lc/q;

.field public final synthetic n:Lc/r;


# direct methods
.method public constructor <init>(Lc/r;Landroidx/lifecycle/t;Lr0/k;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const-string v0, "lifecycle"

    .line 5
    .line 6
    invoke-static {p2, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    const-string v0, "onBackPressedCallback"

    .line 10
    .line 11
    invoke-static {p3, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    iput-object p1, p0, Lc/p;->n:Lc/r;

    .line 15
    .line 16
    iput-object p2, p0, Lc/p;->k:Landroidx/lifecycle/t;

    .line 17
    .line 18
    iput-object p3, p0, Lc/p;->l:Lr0/k;

    .line 19
    .line 20
    invoke-virtual {p2, p0}, Landroidx/lifecycle/t;->a(Landroidx/lifecycle/q;)V

    .line 21
    .line 22
    .line 23
    return-void
.end method


# virtual methods
.method public final a(Landroidx/lifecycle/r;Landroidx/lifecycle/j;)V
    .locals 3

    .line 1
    sget-object p1, Landroidx/lifecycle/j;->ON_START:Landroidx/lifecycle/j;

    .line 2
    .line 3
    if-ne p2, p1, :cond_1

    .line 4
    .line 5
    const-string p1, "onBackPressedCallback"

    .line 6
    .line 7
    iget-object p2, p0, Lc/p;->l:Lr0/k;

    .line 8
    .line 9
    invoke-static {p2, p1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    iget-object p1, p0, Lc/p;->n:Lc/r;

    .line 13
    .line 14
    iget-object v0, p1, Lc/r;->b:Lo6/h;

    .line 15
    .line 16
    invoke-virtual {v0, p2}, Lo6/h;->addLast(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    new-instance v0, Lc/q;

    .line 20
    .line 21
    invoke-direct {v0, p1, p2}, Lc/q;-><init>(Lc/r;Lr0/k;)V

    .line 22
    .line 23
    .line 24
    iget-object v1, p2, Lr0/k;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 25
    .line 26
    invoke-virtual {v1, v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 30
    .line 31
    const/16 v2, 0x21

    .line 32
    .line 33
    if-lt v1, v2, :cond_0

    .line 34
    .line 35
    invoke-virtual {p1}, Lc/r;->b()V

    .line 36
    .line 37
    .line 38
    iget-object p1, p1, Lc/r;->c:Lc/m;

    .line 39
    .line 40
    iput-object p1, p2, Lr0/k;->c:Lz6/a;

    .line 41
    .line 42
    :cond_0
    iput-object v0, p0, Lc/p;->m:Lc/q;

    .line 43
    .line 44
    return-void

    .line 45
    :cond_1
    sget-object p1, Landroidx/lifecycle/j;->ON_STOP:Landroidx/lifecycle/j;

    .line 46
    .line 47
    if-ne p2, p1, :cond_2

    .line 48
    .line 49
    iget-object p1, p0, Lc/p;->m:Lc/q;

    .line 50
    .line 51
    if-eqz p1, :cond_3

    .line 52
    .line 53
    invoke-virtual {p1}, Lc/q;->cancel()V

    .line 54
    .line 55
    .line 56
    return-void

    .line 57
    :cond_2
    sget-object p1, Landroidx/lifecycle/j;->ON_DESTROY:Landroidx/lifecycle/j;

    .line 58
    .line 59
    if-ne p2, p1, :cond_3

    .line 60
    .line 61
    invoke-virtual {p0}, Lc/p;->cancel()V

    .line 62
    .line 63
    .line 64
    :cond_3
    return-void
.end method

.method public final cancel()V
    .locals 1

    .line 1
    iget-object v0, p0, Lc/p;->k:Landroidx/lifecycle/t;

    .line 2
    .line 3
    invoke-virtual {v0, p0}, Landroidx/lifecycle/t;->f(Landroidx/lifecycle/q;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lc/p;->l:Lr0/k;

    .line 7
    .line 8
    iget-object v0, v0, Lr0/k;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 9
    .line 10
    invoke-virtual {v0, p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, Lc/p;->m:Lc/q;

    .line 14
    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    invoke-virtual {v0}, Lc/q;->cancel()V

    .line 18
    .line 19
    .line 20
    :cond_0
    const/4 v0, 0x0

    .line 21
    iput-object v0, p0, Lc/p;->m:Lc/q;

    .line 22
    .line 23
    return-void
.end method
