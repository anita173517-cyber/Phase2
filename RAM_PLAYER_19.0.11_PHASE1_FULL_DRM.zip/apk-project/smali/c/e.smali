.class public final Lc/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic k:I

.field public final l:I

.field public final m:Ljava/lang/Object;

.field public final n:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;ILjava/lang/Object;I)V
    .locals 0

    .line 1
    iput p4, p0, Lc/e;->k:I

    iput-object p1, p0, Lc/e;->m:Ljava/lang/Object;

    iput p2, p0, Lc/e;->l:I

    iput-object p3, p0, Lc/e;->n:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;II)V
    .locals 0

    .line 2
    iput p4, p0, Lc/e;->k:I

    iput-object p1, p0, Lc/e;->n:Ljava/lang/Object;

    iput-object p2, p0, Lc/e;->m:Ljava/lang/Object;

    iput p3, p0, Lc/e;->l:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    .line 1
    iget v0, p0, Lc/e;->k:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lc/e;->n:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Landroid/widget/TextView;

    .line 9
    .line 10
    iget-object v1, p0, Lc/e;->m:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, Landroid/graphics/Typeface;

    .line 13
    .line 14
    iget v2, p0, Lc/e;->l:I

    .line 15
    .line 16
    invoke-virtual {v0, v1, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 17
    .line 18
    .line 19
    return-void

    .line 20
    :pswitch_0
    iget-object v0, p0, Lc/e;->m:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v0, Landroidx/work/impl/foreground/SystemForegroundService;

    .line 23
    .line 24
    iget-object v0, v0, Landroidx/work/impl/foreground/SystemForegroundService;->o:Landroid/app/NotificationManager;

    .line 25
    .line 26
    iget-object v1, p0, Lc/e;->n:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast v1, Landroid/app/Notification;

    .line 29
    .line 30
    iget v2, p0, Lc/e;->l:I

    .line 31
    .line 32
    invoke-virtual {v0, v2, v1}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    .line 33
    .line 34
    .line 35
    return-void

    .line 36
    :pswitch_1
    iget-object v0, p0, Lc/e;->n:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v0, Lf4/i;

    .line 39
    .line 40
    iget-object v1, p0, Lc/e;->m:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast v1, Landroid/content/Intent;

    .line 43
    .line 44
    iget v2, p0, Lc/e;->l:I

    .line 45
    .line 46
    invoke-virtual {v0, v1, v2}, Lf4/i;->a(Landroid/content/Intent;I)V

    .line 47
    .line 48
    .line 49
    return-void

    .line 50
    :pswitch_2
    iget-object v0, p0, Lc/e;->m:Ljava/lang/Object;

    .line 51
    .line 52
    check-cast v0, Lc/f;

    .line 53
    .line 54
    new-instance v1, Landroid/content/Intent;

    .line 55
    .line 56
    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    .line 57
    .line 58
    .line 59
    const-string v2, "androidx.activity.result.contract.action.INTENT_SENDER_REQUEST"

    .line 60
    .line 61
    invoke-virtual {v1, v2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 62
    .line 63
    .line 64
    move-result-object v1

    .line 65
    iget-object v2, p0, Lc/e;->n:Ljava/lang/Object;

    .line 66
    .line 67
    check-cast v2, Landroid/content/IntentSender$SendIntentException;

    .line 68
    .line 69
    const-string v3, "androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION"

    .line 70
    .line 71
    invoke-virtual {v1, v3, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;

    .line 72
    .line 73
    .line 74
    move-result-object v1

    .line 75
    iget v2, p0, Lc/e;->l:I

    .line 76
    .line 77
    const/4 v3, 0x0

    .line 78
    invoke-virtual {v0, v2, v3, v1}, Lc/f;->a(IILandroid/content/Intent;)Z

    .line 79
    .line 80
    .line 81
    return-void

    .line 82
    :pswitch_3
    iget-object v0, p0, Lc/e;->m:Ljava/lang/Object;

    .line 83
    .line 84
    check-cast v0, Lc/f;

    .line 85
    .line 86
    iget-object v1, p0, Lc/e;->n:Ljava/lang/Object;

    .line 87
    .line 88
    check-cast v1, Landroidx/lifecycle/c0;

    .line 89
    .line 90
    iget-object v1, v1, Landroidx/lifecycle/c0;->l:Ljava/lang/Object;

    .line 91
    .line 92
    iget-object v2, v0, Lc/f;->b:Ljava/util/HashMap;

    .line 93
    .line 94
    iget v3, p0, Lc/e;->l:I

    .line 95
    .line 96
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 97
    .line 98
    .line 99
    move-result-object v3

    .line 100
    invoke-virtual {v2, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v2

    .line 104
    check-cast v2, Ljava/lang/String;

    .line 105
    .line 106
    if-nez v2, :cond_0

    .line 107
    .line 108
    goto :goto_0

    .line 109
    :cond_0
    iget-object v3, v0, Lc/f;->f:Ljava/util/HashMap;

    .line 110
    .line 111
    invoke-virtual {v3, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 112
    .line 113
    .line 114
    move-result-object v3

    .line 115
    check-cast v3, Le/f;

    .line 116
    .line 117
    if-eqz v3, :cond_1

    .line 118
    .line 119
    iget-object v3, v3, Le/f;->a:Le/b;

    .line 120
    .line 121
    iget-object v0, v0, Lc/f;->e:Ljava/util/ArrayList;

    .line 122
    .line 123
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 124
    .line 125
    .line 126
    move-result v0

    .line 127
    if-eqz v0, :cond_2

    .line 128
    .line 129
    invoke-interface {v3, v1}, Le/b;->a(Ljava/lang/Object;)V

    .line 130
    .line 131
    .line 132
    goto :goto_0

    .line 133
    :cond_1
    iget-object v3, v0, Lc/f;->h:Landroid/os/Bundle;

    .line 134
    .line 135
    invoke-virtual {v3, v2}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 136
    .line 137
    .line 138
    iget-object v0, v0, Lc/f;->g:Ljava/util/HashMap;

    .line 139
    .line 140
    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 141
    .line 142
    .line 143
    :cond_2
    :goto_0
    return-void

    .line 144
    nop

    .line 145
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
