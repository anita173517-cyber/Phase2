.class public final Lc/r;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/Runnable;

.field public final b:Lo6/h;

.field public final c:Lc/m;

.field public final d:Landroid/window/OnBackInvokedCallback;

.field public e:Landroid/window/OnBackInvokedDispatcher;

.field public f:Z


# direct methods
.method public constructor <init>(Ljava/lang/Runnable;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lc/r;->a:Ljava/lang/Runnable;

    .line 5
    .line 6
    new-instance p1, Lo6/h;

    .line 7
    .line 8
    invoke-direct {p1}, Lo6/h;-><init>()V

    .line 9
    .line 10
    .line 11
    iput-object p1, p0, Lc/r;->b:Lo6/h;

    .line 12
    .line 13
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 14
    .line 15
    const/16 v0, 0x21

    .line 16
    .line 17
    if-lt p1, v0, :cond_0

    .line 18
    .line 19
    new-instance p1, Lc/m;

    .line 20
    .line 21
    const/4 v0, 0x0

    .line 22
    invoke-direct {p1, p0, v0}, Lc/m;-><init>(Lc/r;I)V

    .line 23
    .line 24
    .line 25
    iput-object p1, p0, Lc/r;->c:Lc/m;

    .line 26
    .line 27
    new-instance p1, Lc/m;

    .line 28
    .line 29
    const/4 v0, 0x1

    .line 30
    invoke-direct {p1, p0, v0}, Lc/m;-><init>(Lc/r;I)V

    .line 31
    .line 32
    .line 33
    sget-object v0, Lc/o;->a:Lc/o;

    .line 34
    .line 35
    invoke-virtual {v0, p1}, Lc/o;->a(Lz6/a;)Landroid/window/OnBackInvokedCallback;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    iput-object p1, p0, Lc/r;->d:Landroid/window/OnBackInvokedCallback;

    .line 40
    .line 41
    :cond_0
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 8

    .line 1
    iget-object v0, p0, Lc/r;->b:Lo6/h;

    .line 2
    .line 3
    invoke-virtual {v0}, Lo6/h;->f()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    invoke-virtual {v0, v1}, Ljava/util/AbstractList;->listIterator(I)Ljava/util/ListIterator;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    :cond_0
    invoke-interface {v0}, Ljava/util/ListIterator;->hasPrevious()Z

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    const/4 v2, 0x0

    .line 16
    if-eqz v1, :cond_1

    .line 17
    .line 18
    invoke-interface {v0}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    move-object v3, v1

    .line 23
    check-cast v3, Lr0/k;

    .line 24
    .line 25
    iget-boolean v3, v3, Lr0/k;->a:Z

    .line 26
    .line 27
    if-eqz v3, :cond_0

    .line 28
    .line 29
    goto :goto_0

    .line 30
    :cond_1
    move-object v1, v2

    .line 31
    :goto_0
    check-cast v1, Lr0/k;

    .line 32
    .line 33
    if-eqz v1, :cond_7

    .line 34
    .line 35
    iget-object v0, v1, Lr0/k;->d:Lr0/o;

    .line 36
    .line 37
    const/4 v1, 0x1

    .line 38
    invoke-virtual {v0, v1}, Lr0/o;->e(Z)Z

    .line 39
    .line 40
    .line 41
    iget-object v3, v0, Lr0/o;->g:Lr0/k;

    .line 42
    .line 43
    iget-boolean v3, v3, Lr0/k;->a:Z

    .line 44
    .line 45
    if-eqz v3, :cond_6

    .line 46
    .line 47
    const/4 v3, 0x0

    .line 48
    invoke-virtual {v0, v3}, Lr0/o;->e(Z)Z

    .line 49
    .line 50
    .line 51
    invoke-virtual {v0, v1}, Lr0/o;->d(Z)V

    .line 52
    .line 53
    .line 54
    iget-object v3, v0, Lr0/o;->B:Ljava/util/ArrayList;

    .line 55
    .line 56
    iget-object v4, v0, Lr0/o;->C:Ljava/util/ArrayList;

    .line 57
    .line 58
    iget-object v5, v0, Lr0/o;->d:Ljava/util/ArrayList;

    .line 59
    .line 60
    if-eqz v5, :cond_3

    .line 61
    .line 62
    invoke-virtual {v5}, Ljava/util/ArrayList;->isEmpty()Z

    .line 63
    .line 64
    .line 65
    move-result v5

    .line 66
    if-eqz v5, :cond_2

    .line 67
    .line 68
    goto :goto_1

    .line 69
    :cond_2
    iget-object v5, v0, Lr0/o;->d:Ljava/util/ArrayList;

    .line 70
    .line 71
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    .line 72
    .line 73
    .line 74
    move-result v5

    .line 75
    sub-int/2addr v5, v1

    .line 76
    goto :goto_2

    .line 77
    :cond_3
    :goto_1
    const/4 v5, -0x1

    .line 78
    :goto_2
    if-gez v5, :cond_4

    .line 79
    .line 80
    goto :goto_4

    .line 81
    :cond_4
    iget-object v6, v0, Lr0/o;->d:Ljava/util/ArrayList;

    .line 82
    .line 83
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    .line 84
    .line 85
    .line 86
    move-result v6

    .line 87
    sub-int/2addr v6, v1

    .line 88
    :goto_3
    if-lt v6, v5, :cond_5

    .line 89
    .line 90
    iget-object v7, v0, Lr0/o;->d:Ljava/util/ArrayList;

    .line 91
    .line 92
    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v7

    .line 96
    check-cast v7, Lr0/a;

    .line 97
    .line 98
    invoke-virtual {v3, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 99
    .line 100
    .line 101
    sget-object v7, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 102
    .line 103
    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 104
    .line 105
    .line 106
    add-int/lit8 v6, v6, -0x1

    .line 107
    .line 108
    goto :goto_3

    .line 109
    :cond_5
    iput-boolean v1, v0, Lr0/o;->b:Z

    .line 110
    .line 111
    :try_start_0
    iget-object v1, v0, Lr0/o;->B:Ljava/util/ArrayList;

    .line 112
    .line 113
    iget-object v3, v0, Lr0/o;->C:Ljava/util/ArrayList;

    .line 114
    .line 115
    invoke-virtual {v0, v1, v3}, Lr0/o;->j(Ljava/util/ArrayList;Ljava/util/ArrayList;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 116
    .line 117
    .line 118
    invoke-virtual {v0}, Lr0/o;->a()V

    .line 119
    .line 120
    .line 121
    :goto_4
    invoke-virtual {v0}, Lr0/o;->k()V

    .line 122
    .line 123
    .line 124
    iget-object v0, v0, Lr0/o;->c:Ll4/i;

    .line 125
    .line 126
    iget-object v0, v0, Ll4/i;->l:Ljava/lang/Object;

    .line 127
    .line 128
    check-cast v0, Ljava/util/HashMap;

    .line 129
    .line 130
    invoke-virtual {v0}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    .line 131
    .line 132
    .line 133
    move-result-object v0

    .line 134
    invoke-static {v2}, Ljava/util/Collections;->singleton(Ljava/lang/Object;)Ljava/util/Set;

    .line 135
    .line 136
    .line 137
    move-result-object v1

    .line 138
    invoke-interface {v0, v1}, Ljava/util/Collection;->removeAll(Ljava/util/Collection;)Z

    .line 139
    .line 140
    .line 141
    return-void

    .line 142
    :catchall_0
    move-exception v1

    .line 143
    invoke-virtual {v0}, Lr0/o;->a()V

    .line 144
    .line 145
    .line 146
    throw v1

    .line 147
    :cond_6
    iget-object v0, v0, Lr0/o;->f:Lc/r;

    .line 148
    .line 149
    invoke-virtual {v0}, Lc/r;->a()V

    .line 150
    .line 151
    .line 152
    return-void

    .line 153
    :cond_7
    iget-object v0, p0, Lc/r;->a:Ljava/lang/Runnable;

    .line 154
    .line 155
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    .line 156
    .line 157
    .line 158
    return-void
.end method

.method public final b()V
    .locals 7

    .line 1
    const/4 v0, 0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    iget-object v2, p0, Lc/r;->b:Lo6/h;

    .line 4
    .line 5
    if-eqz v2, :cond_1

    .line 6
    .line 7
    invoke-virtual {v2}, Lo6/h;->isEmpty()Z

    .line 8
    .line 9
    .line 10
    move-result v3

    .line 11
    if-eqz v3, :cond_1

    .line 12
    .line 13
    :cond_0
    move v2, v1

    .line 14
    goto :goto_0

    .line 15
    :cond_1
    invoke-virtual {v2}, Ljava/util/AbstractList;->iterator()Ljava/util/Iterator;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    :cond_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 20
    .line 21
    .line 22
    move-result v3

    .line 23
    if-eqz v3, :cond_0

    .line 24
    .line 25
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    check-cast v3, Lr0/k;

    .line 30
    .line 31
    iget-boolean v3, v3, Lr0/k;->a:Z

    .line 32
    .line 33
    if-eqz v3, :cond_2

    .line 34
    .line 35
    move v2, v0

    .line 36
    :goto_0
    iget-object v3, p0, Lc/r;->e:Landroid/window/OnBackInvokedDispatcher;

    .line 37
    .line 38
    iget-object v4, p0, Lc/r;->d:Landroid/window/OnBackInvokedCallback;

    .line 39
    .line 40
    if-eqz v3, :cond_4

    .line 41
    .line 42
    if-eqz v4, :cond_4

    .line 43
    .line 44
    sget-object v5, Lc/o;->a:Lc/o;

    .line 45
    .line 46
    if-eqz v2, :cond_3

    .line 47
    .line 48
    iget-boolean v6, p0, Lc/r;->f:Z

    .line 49
    .line 50
    if-nez v6, :cond_3

    .line 51
    .line 52
    invoke-virtual {v5, v3, v1, v4}, Lc/o;->b(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    iput-boolean v0, p0, Lc/r;->f:Z

    .line 56
    .line 57
    return-void

    .line 58
    :cond_3
    if-nez v2, :cond_4

    .line 59
    .line 60
    iget-boolean v0, p0, Lc/r;->f:Z

    .line 61
    .line 62
    if-eqz v0, :cond_4

    .line 63
    .line 64
    invoke-virtual {v5, v3, v4}, Lc/o;->c(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    iput-boolean v1, p0, Lc/r;->f:Z

    .line 68
    .line 69
    :cond_4
    return-void
.end method
