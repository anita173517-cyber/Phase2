.class public final Lc4/s;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Z

.field public b:Ljava/util/UUID;

.field public c:Ll4/q;

.field public final d:Ljava/util/Set;

.field public final synthetic e:I


# direct methods
.method public constructor <init>(ILjava/lang/Class;)V
    .locals 35

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move/from16 v1, p1

    .line 4
    .line 5
    iput v1, v0, Lc4/s;->e:I

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    const-string v2, "randomUUID()"

    .line 15
    .line 16
    invoke-static {v1, v2}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    iput-object v1, v0, Lc4/s;->b:Ljava/util/UUID;

    .line 20
    .line 21
    new-instance v3, Ll4/q;

    .line 22
    .line 23
    iget-object v1, v0, Lc4/s;->b:Ljava/util/UUID;

    .line 24
    .line 25
    invoke-virtual {v1}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v4

    .line 29
    const-string v1, "id.toString()"

    .line 30
    .line 31
    invoke-static {v4, v1}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    invoke-virtual/range {p2 .. p2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v6

    .line 38
    const/16 v18, 0x0

    .line 39
    .line 40
    const/16 v28, 0x0

    .line 41
    .line 42
    const/4 v5, 0x0

    .line 43
    const/4 v7, 0x0

    .line 44
    const/4 v8, 0x0

    .line 45
    const/4 v9, 0x0

    .line 46
    const-wide/16 v10, 0x0

    .line 47
    .line 48
    const-wide/16 v12, 0x0

    .line 49
    .line 50
    const-wide/16 v14, 0x0

    .line 51
    .line 52
    const/16 v16, 0x0

    .line 53
    .line 54
    const/16 v17, 0x0

    .line 55
    .line 56
    const-wide/16 v19, 0x0

    .line 57
    .line 58
    const-wide/16 v21, 0x0

    .line 59
    .line 60
    const-wide/16 v23, 0x0

    .line 61
    .line 62
    const-wide/16 v25, 0x0

    .line 63
    .line 64
    const/16 v27, 0x0

    .line 65
    .line 66
    const/16 v29, 0x0

    .line 67
    .line 68
    const-wide/16 v30, 0x0

    .line 69
    .line 70
    const/16 v32, 0x0

    .line 71
    .line 72
    const/16 v33, 0x0

    .line 73
    .line 74
    const v34, 0x7ffffa

    .line 75
    .line 76
    .line 77
    invoke-direct/range {v3 .. v34}, Ll4/q;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Lc4/f;Lc4/f;JJJLc4/c;IIJJJJZIIJIII)V

    .line 78
    .line 79
    .line 80
    iput-object v3, v0, Lc4/s;->c:Ll4/q;

    .line 81
    .line 82
    invoke-virtual/range {p2 .. p2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object v1

    .line 86
    filled-new-array {v1}, [Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    new-instance v2, Ljava/util/LinkedHashSet;

    .line 91
    .line 92
    const/4 v3, 0x1

    .line 93
    invoke-static {v3}, Lo6/v;->L(I)I

    .line 94
    .line 95
    .line 96
    move-result v3

    .line 97
    invoke-direct {v2, v3}, Ljava/util/LinkedHashSet;-><init>(I)V

    .line 98
    .line 99
    .line 100
    invoke-static {v1, v2}, Lo6/i;->b0([Ljava/lang/Object;Ljava/util/HashSet;)V

    .line 101
    .line 102
    .line 103
    iput-object v2, v0, Lc4/s;->d:Ljava/util/Set;

    .line 104
    .line 105
    return-void
.end method


# virtual methods
.method public final a()Lc4/c0;
    .locals 37

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, Lc4/s;->e:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    iget-boolean v1, v0, Lc4/s;->a:Z

    .line 9
    .line 10
    if-eqz v1, :cond_1

    .line 11
    .line 12
    iget-object v1, v0, Lc4/s;->c:Ll4/q;

    .line 13
    .line 14
    iget-object v1, v1, Ll4/q;->j:Lc4/c;

    .line 15
    .line 16
    iget-boolean v1, v1, Lc4/c;->c:Z

    .line 17
    .line 18
    if-nez v1, :cond_0

    .line 19
    .line 20
    goto :goto_0

    .line 21
    :cond_0
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 22
    .line 23
    const-string v2, "Cannot set backoff criteria on an idle mode job"

    .line 24
    .line 25
    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    throw v1

    .line 29
    :cond_1
    :goto_0
    iget-object v1, v0, Lc4/s;->c:Ll4/q;

    .line 30
    .line 31
    iget-boolean v2, v1, Ll4/q;->q:Z

    .line 32
    .line 33
    if-nez v2, :cond_2

    .line 34
    .line 35
    new-instance v2, Lc4/y;

    .line 36
    .line 37
    iget-object v3, v0, Lc4/s;->b:Ljava/util/UUID;

    .line 38
    .line 39
    iget-object v4, v0, Lc4/s;->d:Ljava/util/Set;

    .line 40
    .line 41
    invoke-direct {v2, v3, v1, v4}, Lc4/c0;-><init>(Ljava/util/UUID;Ll4/q;Ljava/util/Set;)V

    .line 42
    .line 43
    .line 44
    goto :goto_2

    .line 45
    :cond_2
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 46
    .line 47
    const-string v2, "PeriodicWorkRequests cannot be expedited"

    .line 48
    .line 49
    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    throw v1

    .line 53
    :pswitch_0
    iget-boolean v1, v0, Lc4/s;->a:Z

    .line 54
    .line 55
    if-eqz v1, :cond_4

    .line 56
    .line 57
    iget-object v1, v0, Lc4/s;->c:Ll4/q;

    .line 58
    .line 59
    iget-object v1, v1, Ll4/q;->j:Lc4/c;

    .line 60
    .line 61
    iget-boolean v1, v1, Lc4/c;->c:Z

    .line 62
    .line 63
    if-nez v1, :cond_3

    .line 64
    .line 65
    goto :goto_1

    .line 66
    :cond_3
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 67
    .line 68
    const-string v2, "Cannot set backoff criteria on an idle mode job"

    .line 69
    .line 70
    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 71
    .line 72
    .line 73
    throw v1

    .line 74
    :cond_4
    :goto_1
    new-instance v2, Lc4/t;

    .line 75
    .line 76
    iget-object v1, v0, Lc4/s;->b:Ljava/util/UUID;

    .line 77
    .line 78
    iget-object v3, v0, Lc4/s;->c:Ll4/q;

    .line 79
    .line 80
    iget-object v4, v0, Lc4/s;->d:Ljava/util/Set;

    .line 81
    .line 82
    invoke-direct {v2, v1, v3, v4}, Lc4/c0;-><init>(Ljava/util/UUID;Ll4/q;Ljava/util/Set;)V

    .line 83
    .line 84
    .line 85
    :goto_2
    iget-object v1, v0, Lc4/s;->c:Ll4/q;

    .line 86
    .line 87
    iget-object v1, v1, Ll4/q;->j:Lc4/c;

    .line 88
    .line 89
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 90
    .line 91
    const/16 v4, 0x18

    .line 92
    .line 93
    if-lt v3, v4, :cond_5

    .line 94
    .line 95
    invoke-virtual {v1}, Lc4/c;->a()Z

    .line 96
    .line 97
    .line 98
    move-result v3

    .line 99
    if-nez v3, :cond_7

    .line 100
    .line 101
    :cond_5
    iget-boolean v3, v1, Lc4/c;->d:Z

    .line 102
    .line 103
    if-nez v3, :cond_7

    .line 104
    .line 105
    iget-boolean v3, v1, Lc4/c;->b:Z

    .line 106
    .line 107
    if-nez v3, :cond_7

    .line 108
    .line 109
    iget-boolean v1, v1, Lc4/c;->c:Z

    .line 110
    .line 111
    if-eqz v1, :cond_6

    .line 112
    .line 113
    goto :goto_3

    .line 114
    :cond_6
    const/4 v1, 0x0

    .line 115
    goto :goto_4

    .line 116
    :cond_7
    :goto_3
    const/4 v1, 0x1

    .line 117
    :goto_4
    iget-object v3, v0, Lc4/s;->c:Ll4/q;

    .line 118
    .line 119
    iget-boolean v4, v3, Ll4/q;->q:Z

    .line 120
    .line 121
    if-eqz v4, :cond_a

    .line 122
    .line 123
    if-nez v1, :cond_9

    .line 124
    .line 125
    iget-wide v3, v3, Ll4/q;->g:J

    .line 126
    .line 127
    const-wide/16 v5, 0x0

    .line 128
    .line 129
    cmp-long v1, v3, v5

    .line 130
    .line 131
    if-gtz v1, :cond_8

    .line 132
    .line 133
    goto :goto_5

    .line 134
    :cond_8
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 135
    .line 136
    const-string v2, "Expedited jobs cannot be delayed"

    .line 137
    .line 138
    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 139
    .line 140
    .line 141
    throw v1

    .line 142
    :cond_9
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 143
    .line 144
    const-string v2, "Expedited jobs only support network and storage constraints"

    .line 145
    .line 146
    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 147
    .line 148
    .line 149
    throw v1

    .line 150
    :cond_a
    :goto_5
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 151
    .line 152
    .line 153
    move-result-object v1

    .line 154
    const-string v3, "randomUUID()"

    .line 155
    .line 156
    invoke-static {v1, v3}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 157
    .line 158
    .line 159
    iput-object v1, v0, Lc4/s;->b:Ljava/util/UUID;

    .line 160
    .line 161
    new-instance v4, Ll4/q;

    .line 162
    .line 163
    invoke-virtual {v1}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 164
    .line 165
    .line 166
    move-result-object v5

    .line 167
    const-string v1, "id.toString()"

    .line 168
    .line 169
    invoke-static {v5, v1}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 170
    .line 171
    .line 172
    iget-object v1, v0, Lc4/s;->c:Ll4/q;

    .line 173
    .line 174
    const-string v3, "other"

    .line 175
    .line 176
    invoke-static {v1, v3}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 177
    .line 178
    .line 179
    iget-object v7, v1, Ll4/q;->c:Ljava/lang/String;

    .line 180
    .line 181
    iget v6, v1, Ll4/q;->b:I

    .line 182
    .line 183
    iget-object v8, v1, Ll4/q;->d:Ljava/lang/String;

    .line 184
    .line 185
    new-instance v9, Lc4/f;

    .line 186
    .line 187
    iget-object v3, v1, Ll4/q;->e:Lc4/f;

    .line 188
    .line 189
    invoke-direct {v9, v3}, Lc4/f;-><init>(Lc4/f;)V

    .line 190
    .line 191
    .line 192
    new-instance v10, Lc4/f;

    .line 193
    .line 194
    iget-object v3, v1, Ll4/q;->f:Lc4/f;

    .line 195
    .line 196
    invoke-direct {v10, v3}, Lc4/f;-><init>(Lc4/f;)V

    .line 197
    .line 198
    .line 199
    iget-wide v11, v1, Ll4/q;->g:J

    .line 200
    .line 201
    iget-wide v13, v1, Ll4/q;->h:J

    .line 202
    .line 203
    move-object/from16 v36, v2

    .line 204
    .line 205
    iget-wide v2, v1, Ll4/q;->i:J

    .line 206
    .line 207
    new-instance v15, Lc4/c;

    .line 208
    .line 209
    move-wide/from16 v16, v2

    .line 210
    .line 211
    iget-object v2, v1, Ll4/q;->j:Lc4/c;

    .line 212
    .line 213
    invoke-direct {v15, v2}, Lc4/c;-><init>(Lc4/c;)V

    .line 214
    .line 215
    .line 216
    iget v2, v1, Ll4/q;->k:I

    .line 217
    .line 218
    iget v3, v1, Ll4/q;->l:I

    .line 219
    .line 220
    move/from16 v18, v2

    .line 221
    .line 222
    move/from16 v19, v3

    .line 223
    .line 224
    iget-wide v2, v1, Ll4/q;->m:J

    .line 225
    .line 226
    move-wide/from16 v20, v2

    .line 227
    .line 228
    iget-wide v2, v1, Ll4/q;->n:J

    .line 229
    .line 230
    move-wide/from16 v22, v2

    .line 231
    .line 232
    iget-wide v2, v1, Ll4/q;->o:J

    .line 233
    .line 234
    move-wide/from16 v24, v2

    .line 235
    .line 236
    iget-wide v2, v1, Ll4/q;->p:J

    .line 237
    .line 238
    move-wide/from16 v26, v2

    .line 239
    .line 240
    iget-boolean v2, v1, Ll4/q;->q:Z

    .line 241
    .line 242
    iget v3, v1, Ll4/q;->r:I

    .line 243
    .line 244
    move/from16 v28, v2

    .line 245
    .line 246
    iget v2, v1, Ll4/q;->s:I

    .line 247
    .line 248
    move/from16 v30, v2

    .line 249
    .line 250
    move/from16 v29, v3

    .line 251
    .line 252
    iget-wide v2, v1, Ll4/q;->u:J

    .line 253
    .line 254
    move-wide/from16 v31, v2

    .line 255
    .line 256
    iget v2, v1, Ll4/q;->v:I

    .line 257
    .line 258
    iget v1, v1, Ll4/q;->w:I

    .line 259
    .line 260
    const/high16 v35, 0x80000

    .line 261
    .line 262
    move-wide/from16 v33, v16

    .line 263
    .line 264
    move-object/from16 v17, v15

    .line 265
    .line 266
    move-wide/from16 v15, v33

    .line 267
    .line 268
    move/from16 v34, v1

    .line 269
    .line 270
    move/from16 v33, v2

    .line 271
    .line 272
    invoke-direct/range {v4 .. v35}, Ll4/q;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Lc4/f;Lc4/f;JJJLc4/c;IIJJJJZIIJIII)V

    .line 273
    .line 274
    .line 275
    iput-object v4, v0, Lc4/s;->c:Ll4/q;

    .line 276
    .line 277
    return-object v36

    .line 278
    nop

    .line 279
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
