.class public abstract Lc4/o;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a()Lc4/n;
    .locals 2

    .line 1
    new-instance v0, Lc4/n;

    .line 2
    .line 3
    sget-object v1, Lc4/f;->c:Lc4/f;

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lc4/n;-><init>(Lc4/f;)V

    .line 6
    .line 7
    .line 8
    return-object v0
.end method
