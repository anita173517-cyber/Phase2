.class public final Landroidx/media3/decoder/ffmpeg/a;
.super Ld1/a;
.source "SourceFile"

# interfaces
.implements Lc1/d;


# instance fields
.field public final D:J

.field public final E:Ll4/c;

.field public final F:Lo/t0;

.field public final G:Ljava/util/ArrayDeque;

.field public final H:Lc1/h;

.field public I:Lv0/t;

.field public J:Ly1/b;

.field public K:I

.field public L:Ljava/lang/Object;

.field public M:Landroid/view/Surface;

.field public N:Ly1/w;

.field public O:Li1/i;

.field public P:Li1/i;

.field public Q:I

.field public R:J

.field public S:Z

.field public T:Lv0/v1;

.field public U:J

.field public V:I

.field public W:I

.field public X:Ld1/c;

.field public Y:Ld1/o0;

.field public Z:Ld1/j0;


# direct methods
.method public constructor <init>(JLandroid/os/Handler;Ly1/g0;I)V
    .locals 0

    .line 1
    const/4 p5, 0x2

    .line 2
    invoke-direct {p0, p5}, Ld1/a;-><init>(I)V

    .line 3
    .line 4
    .line 5
    iput-wide p1, p0, Landroidx/media3/decoder/ffmpeg/a;->D:J

    .line 6
    .line 7
    const-wide p1, -0x7fffffffffffffffL    # -4.9E-324

    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    iput-wide p1, p0, Landroidx/media3/decoder/ffmpeg/a;->R:J

    .line 13
    .line 14
    new-instance p1, Lo/t0;

    .line 15
    .line 16
    invoke-direct {p1}, Lo/t0;-><init>()V

    .line 17
    .line 18
    .line 19
    iput-object p1, p0, Landroidx/media3/decoder/ffmpeg/a;->F:Lo/t0;

    .line 20
    .line 21
    new-instance p1, Ljava/util/ArrayDeque;

    .line 22
    .line 23
    invoke-direct {p1}, Ljava/util/ArrayDeque;-><init>()V

    .line 24
    .line 25
    .line 26
    iput-object p1, p0, Landroidx/media3/decoder/ffmpeg/a;->G:Ljava/util/ArrayDeque;

    .line 27
    .line 28
    new-instance p1, Lc1/h;

    .line 29
    .line 30
    const/4 p2, 0x0

    .line 31
    invoke-direct {p1, p2, p2}, Lc1/h;-><init>(II)V

    .line 32
    .line 33
    .line 34
    iput-object p1, p0, Landroidx/media3/decoder/ffmpeg/a;->H:Lc1/h;

    .line 35
    .line 36
    new-instance p1, Ll4/c;

    .line 37
    .line 38
    invoke-direct {p1, p3, p4}, Ll4/c;-><init>(Landroid/os/Handler;Ly1/g0;)V

    .line 39
    .line 40
    .line 41
    iput-object p1, p0, Landroidx/media3/decoder/ffmpeg/a;->E:Ll4/c;

    .line 42
    .line 43
    const/4 p1, -0x1

    .line 44
    iput p1, p0, Landroidx/media3/decoder/ffmpeg/a;->K:I

    .line 45
    .line 46
    iput p2, p0, Landroidx/media3/decoder/ffmpeg/a;->Q:I

    .line 47
    .line 48
    new-instance p1, Ld1/c;

    .line 49
    .line 50
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 51
    .line 52
    .line 53
    iput-object p1, p0, Landroidx/media3/decoder/ffmpeg/a;->X:Ld1/c;

    .line 54
    .line 55
    return-void
.end method


# virtual methods
.method public final B(JJ)V
    .locals 1

    .line 1
    iget-boolean p1, p0, Landroidx/media3/decoder/ffmpeg/a;->S:Z

    .line 2
    .line 3
    if-eqz p1, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    iget-object p1, p0, Landroidx/media3/decoder/ffmpeg/a;->I:Lv0/t;

    .line 7
    .line 8
    if-nez p1, :cond_3

    .line 9
    .line 10
    iget-object p1, p0, Ld1/a;->m:Ll4/c;

    .line 11
    .line 12
    invoke-virtual {p1}, Ll4/c;->e()V

    .line 13
    .line 14
    .line 15
    iget-object p2, p0, Landroidx/media3/decoder/ffmpeg/a;->H:Lc1/h;

    .line 16
    .line 17
    invoke-virtual {p2}, Lc1/h;->h()V

    .line 18
    .line 19
    .line 20
    const/4 p3, 0x2

    .line 21
    invoke-virtual {p0, p1, p2, p3}, Ld1/a;->A(Ll4/c;Lc1/h;I)I

    .line 22
    .line 23
    .line 24
    move-result p3

    .line 25
    const/4 p4, -0x5

    .line 26
    if-ne p3, p4, :cond_1

    .line 27
    .line 28
    iget-object p2, p1, Ll4/c;->l:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast p2, Lv0/t;

    .line 31
    .line 32
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 33
    .line 34
    .line 35
    iget-object p1, p1, Ll4/c;->k:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast p1, Li1/i;

    .line 38
    .line 39
    iget-object p3, p0, Landroidx/media3/decoder/ffmpeg/a;->P:Li1/i;

    .line 40
    .line 41
    invoke-static {p3, p1}, La0/h;->E(Li1/i;Li1/i;)V

    .line 42
    .line 43
    .line 44
    iput-object p1, p0, Landroidx/media3/decoder/ffmpeg/a;->P:Li1/i;

    .line 45
    .line 46
    iput-object p2, p0, Landroidx/media3/decoder/ffmpeg/a;->I:Lv0/t;

    .line 47
    .line 48
    invoke-virtual {p0}, Landroidx/media3/decoder/ffmpeg/a;->J()V

    .line 49
    .line 50
    .line 51
    iget-object p1, p0, Landroidx/media3/decoder/ffmpeg/a;->I:Lv0/t;

    .line 52
    .line 53
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 54
    .line 55
    .line 56
    iget-object p2, p0, Landroidx/media3/decoder/ffmpeg/a;->E:Ll4/c;

    .line 57
    .line 58
    iget-object p3, p2, Ll4/c;->k:Ljava/lang/Object;

    .line 59
    .line 60
    check-cast p3, Landroid/os/Handler;

    .line 61
    .line 62
    if-eqz p3, :cond_3

    .line 63
    .line 64
    new-instance p4, Lp4/a;

    .line 65
    .line 66
    const/4 v0, 0x0

    .line 67
    invoke-direct {p4, p2, p1, v0}, Lp4/a;-><init>(Ll4/c;Lv0/t;Ld1/d;)V

    .line 68
    .line 69
    .line 70
    invoke-virtual {p3, p4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 71
    .line 72
    .line 73
    goto :goto_1

    .line 74
    :cond_1
    const/4 p1, -0x4

    .line 75
    if-ne p3, p1, :cond_2

    .line 76
    .line 77
    const/4 p1, 0x4

    .line 78
    invoke-virtual {p2, p1}, Lc1/a;->g(I)Z

    .line 79
    .line 80
    .line 81
    move-result p1

    .line 82
    invoke-static {p1}, Landroid/support/v4/media/session/b;->s(Z)V

    .line 83
    .line 84
    .line 85
    const/4 p1, 0x1

    .line 86
    iput-boolean p1, p0, Landroidx/media3/decoder/ffmpeg/a;->S:Z

    .line 87
    .line 88
    :cond_2
    :goto_0
    return-void

    .line 89
    :cond_3
    :goto_1
    invoke-virtual {p0}, Landroidx/media3/decoder/ffmpeg/a;->J()V

    .line 90
    .line 91
    .line 92
    return-void
.end method

.method public final F(Lv0/t;)I
    .locals 0

    .line 1
    const/4 p1, 0x0

    .line 2
    invoke-static {p1, p1, p1, p1}, La0/h;->i(IIII)I

    .line 3
    .line 4
    .line 5
    move-result p1

    .line 6
    return p1
.end method

.method public final J()V
    .locals 7

    .line 1
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/a;->P:Li1/i;

    .line 2
    .line 3
    iget-object v1, p0, Landroidx/media3/decoder/ffmpeg/a;->O:Li1/i;

    .line 4
    .line 5
    invoke-static {v1, v0}, La0/h;->E(Li1/i;Li1/i;)V

    .line 6
    .line 7
    .line 8
    iput-object v0, p0, Landroidx/media3/decoder/ffmpeg/a;->O:Li1/i;

    .line 9
    .line 10
    if-eqz v0, :cond_1

    .line 11
    .line 12
    invoke-interface {v0}, Li1/i;->h()Lc1/b;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    if-nez v0, :cond_1

    .line 17
    .line 18
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/a;->O:Li1/i;

    .line 19
    .line 20
    invoke-interface {v0}, Li1/i;->g()Li1/h;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    if-eqz v0, :cond_0

    .line 25
    .line 26
    goto :goto_0

    .line 27
    :cond_0
    return-void

    .line 28
    :cond_1
    :goto_0
    const/4 v0, 0x0

    .line 29
    const/16 v1, 0xfa1

    .line 30
    .line 31
    :try_start_0
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 32
    .line 33
    .line 34
    iget-object v2, p0, Landroidx/media3/decoder/ffmpeg/a;->Z:Ld1/j0;

    .line 35
    .line 36
    if-nez v2, :cond_2

    .line 37
    .line 38
    new-instance v2, Landroid/os/Handler;

    .line 39
    .line 40
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    .line 41
    .line 42
    .line 43
    move-result-object v3

    .line 44
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 45
    .line 46
    .line 47
    invoke-direct {v2, v3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 48
    .line 49
    .line 50
    new-instance v3, Ld1/j0;

    .line 51
    .line 52
    const/4 v4, 0x1

    .line 53
    invoke-direct {v3, v4, v2}, Ld1/j0;-><init>(ILjava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    iput-object v3, p0, Landroidx/media3/decoder/ffmpeg/a;->Z:Ld1/j0;

    .line 57
    .line 58
    goto :goto_1

    .line 59
    :catch_0
    move-exception v2

    .line 60
    goto :goto_2

    .line 61
    :catch_1
    move-exception v2

    .line 62
    goto :goto_3

    .line 63
    :cond_2
    :goto_1
    iget-object v2, p0, Landroidx/media3/decoder/ffmpeg/a;->I:Lv0/t;

    .line 64
    .line 65
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 66
    .line 67
    .line 68
    const-string v2, "createFfmpegVideoDecoder"

    .line 69
    .line 70
    invoke-static {v2}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 71
    .line 72
    .line 73
    invoke-static {}, Landroid/os/Trace;->endSection()V
    :try_end_0
    .catch Lc1/f; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/OutOfMemoryError; {:try_start_0 .. :try_end_0} :catch_0

    .line 74
    .line 75
    .line 76
    const/4 v0, 0x0

    .line 77
    throw v0

    .line 78
    :goto_2
    iget-object v3, p0, Landroidx/media3/decoder/ffmpeg/a;->I:Lv0/t;

    .line 79
    .line 80
    invoke-virtual {p0, v2, v3, v0, v1}, Ld1/a;->h(Ljava/lang/Throwable;Lv0/t;ZI)Ld1/k;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    throw v0

    .line 85
    :goto_3
    const-string v3, "DecoderVideoRenderer"

    .line 86
    .line 87
    const-string v4, "Video codec error"

    .line 88
    .line 89
    invoke-static {v3, v4, v2}, Ly0/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 90
    .line 91
    .line 92
    iget-object v3, p0, Landroidx/media3/decoder/ffmpeg/a;->E:Ll4/c;

    .line 93
    .line 94
    iget-object v4, v3, Ll4/c;->k:Ljava/lang/Object;

    .line 95
    .line 96
    check-cast v4, Landroid/os/Handler;

    .line 97
    .line 98
    if-eqz v4, :cond_3

    .line 99
    .line 100
    new-instance v5, Ly1/f0;

    .line 101
    .line 102
    const/4 v6, 0x1

    .line 103
    invoke-direct {v5, v3, v2, v6}, Ly1/f0;-><init>(Ll4/c;Ljava/lang/Object;I)V

    .line 104
    .line 105
    .line 106
    invoke-virtual {v4, v5}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 107
    .line 108
    .line 109
    :cond_3
    iget-object v3, p0, Landroidx/media3/decoder/ffmpeg/a;->I:Lv0/t;

    .line 110
    .line 111
    invoke-virtual {p0, v2, v3, v0, v1}, Ld1/a;->h(Ljava/lang/Throwable;Lv0/t;ZI)Ld1/k;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    throw v0
.end method

.method public final a()V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/a;->Y:Ld1/o0;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0}, Ld1/o0;->a()V

    .line 6
    .line 7
    .line 8
    :cond_0
    return-void
.end method

.method public final b(ILjava/lang/Object;)V
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p1, v0, :cond_7

    .line 3
    .line 4
    instance-of p1, p2, Landroid/view/Surface;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    if-eqz p1, :cond_0

    .line 8
    .line 9
    move-object p1, p2

    .line 10
    check-cast p1, Landroid/view/Surface;

    .line 11
    .line 12
    iput-object p1, p0, Landroidx/media3/decoder/ffmpeg/a;->M:Landroid/view/Surface;

    .line 13
    .line 14
    iput-object v1, p0, Landroidx/media3/decoder/ffmpeg/a;->N:Ly1/w;

    .line 15
    .line 16
    iput v0, p0, Landroidx/media3/decoder/ffmpeg/a;->K:I

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_0
    instance-of p1, p2, Ly1/w;

    .line 20
    .line 21
    if-eqz p1, :cond_1

    .line 22
    .line 23
    iput-object v1, p0, Landroidx/media3/decoder/ffmpeg/a;->M:Landroid/view/Surface;

    .line 24
    .line 25
    move-object p1, p2

    .line 26
    check-cast p1, Ly1/w;

    .line 27
    .line 28
    iput-object p1, p0, Landroidx/media3/decoder/ffmpeg/a;->N:Ly1/w;

    .line 29
    .line 30
    const/4 p1, 0x0

    .line 31
    iput p1, p0, Landroidx/media3/decoder/ffmpeg/a;->K:I

    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_1
    iput-object v1, p0, Landroidx/media3/decoder/ffmpeg/a;->M:Landroid/view/Surface;

    .line 35
    .line 36
    iput-object v1, p0, Landroidx/media3/decoder/ffmpeg/a;->N:Ly1/w;

    .line 37
    .line 38
    const/4 p1, -0x1

    .line 39
    iput p1, p0, Landroidx/media3/decoder/ffmpeg/a;->K:I

    .line 40
    .line 41
    move-object p2, v1

    .line 42
    :goto_0
    iget-object p1, p0, Landroidx/media3/decoder/ffmpeg/a;->L:Ljava/lang/Object;

    .line 43
    .line 44
    iget-object v2, p0, Landroidx/media3/decoder/ffmpeg/a;->E:Ll4/c;

    .line 45
    .line 46
    if-eq p1, p2, :cond_5

    .line 47
    .line 48
    iput-object p2, p0, Landroidx/media3/decoder/ffmpeg/a;->L:Ljava/lang/Object;

    .line 49
    .line 50
    if-eqz p2, :cond_4

    .line 51
    .line 52
    iget-object p1, p0, Landroidx/media3/decoder/ffmpeg/a;->T:Lv0/v1;

    .line 53
    .line 54
    if-eqz p1, :cond_2

    .line 55
    .line 56
    invoke-virtual {v2, p1}, Ll4/c;->w(Lv0/v1;)V

    .line 57
    .line 58
    .line 59
    :cond_2
    iget p1, p0, Landroidx/media3/decoder/ffmpeg/a;->Q:I

    .line 60
    .line 61
    invoke-static {p1, v0}, Ljava/lang/Math;->min(II)I

    .line 62
    .line 63
    .line 64
    move-result p1

    .line 65
    iput p1, p0, Landroidx/media3/decoder/ffmpeg/a;->Q:I

    .line 66
    .line 67
    iget p1, p0, Ld1/a;->r:I

    .line 68
    .line 69
    const/4 p2, 0x2

    .line 70
    if-ne p1, p2, :cond_9

    .line 71
    .line 72
    const-wide/16 p1, 0x0

    .line 73
    .line 74
    iget-wide v0, p0, Landroidx/media3/decoder/ffmpeg/a;->D:J

    .line 75
    .line 76
    cmp-long p1, v0, p1

    .line 77
    .line 78
    if-lez p1, :cond_3

    .line 79
    .line 80
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 81
    .line 82
    .line 83
    move-result-wide p1

    .line 84
    add-long/2addr p1, v0

    .line 85
    goto :goto_1

    .line 86
    :cond_3
    const-wide p1, -0x7fffffffffffffffL    # -4.9E-324

    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    :goto_1
    iput-wide p1, p0, Landroidx/media3/decoder/ffmpeg/a;->R:J

    .line 92
    .line 93
    return-void

    .line 94
    :cond_4
    iput-object v1, p0, Landroidx/media3/decoder/ffmpeg/a;->T:Lv0/v1;

    .line 95
    .line 96
    iget p1, p0, Landroidx/media3/decoder/ffmpeg/a;->Q:I

    .line 97
    .line 98
    invoke-static {p1, v0}, Ljava/lang/Math;->min(II)I

    .line 99
    .line 100
    .line 101
    move-result p1

    .line 102
    iput p1, p0, Landroidx/media3/decoder/ffmpeg/a;->Q:I

    .line 103
    .line 104
    return-void

    .line 105
    :cond_5
    if-eqz p2, :cond_9

    .line 106
    .line 107
    iget-object p1, p0, Landroidx/media3/decoder/ffmpeg/a;->T:Lv0/v1;

    .line 108
    .line 109
    if-eqz p1, :cond_6

    .line 110
    .line 111
    invoke-virtual {v2, p1}, Ll4/c;->w(Lv0/v1;)V

    .line 112
    .line 113
    .line 114
    :cond_6
    iget p1, p0, Landroidx/media3/decoder/ffmpeg/a;->Q:I

    .line 115
    .line 116
    const/4 p2, 0x3

    .line 117
    if-ne p1, p2, :cond_9

    .line 118
    .line 119
    iget-object p1, p0, Landroidx/media3/decoder/ffmpeg/a;->L:Ljava/lang/Object;

    .line 120
    .line 121
    if-eqz p1, :cond_9

    .line 122
    .line 123
    iget-object p2, v2, Ll4/c;->k:Ljava/lang/Object;

    .line 124
    .line 125
    check-cast p2, Landroid/os/Handler;

    .line 126
    .line 127
    if-eqz p2, :cond_9

    .line 128
    .line 129
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 130
    .line 131
    .line 132
    move-result-wide v0

    .line 133
    new-instance v3, Lm6/n3;

    .line 134
    .line 135
    invoke-direct {v3, v2, p1, v0, v1}, Lm6/n3;-><init>(Ll4/c;Ljava/lang/Object;J)V

    .line 136
    .line 137
    .line 138
    invoke-virtual {p2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 139
    .line 140
    .line 141
    return-void

    .line 142
    :cond_7
    const/4 v0, 0x7

    .line 143
    if-ne p1, v0, :cond_8

    .line 144
    .line 145
    check-cast p2, Ly1/x;

    .line 146
    .line 147
    return-void

    .line 148
    :cond_8
    const/16 v0, 0xb

    .line 149
    .line 150
    if-ne p1, v0, :cond_9

    .line 151
    .line 152
    check-cast p2, Ld1/o0;

    .line 153
    .line 154
    iput-object p2, p0, Landroidx/media3/decoder/ffmpeg/a;->Y:Ld1/o0;

    .line 155
    .line 156
    :cond_9
    return-void
.end method

.method public final c()V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/a;->Y:Ld1/o0;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0}, Ld1/o0;->a()V

    .line 6
    .line 7
    .line 8
    :cond_0
    return-void
.end method

.method public final i()V
    .locals 1

    .line 1
    iget v0, p0, Landroidx/media3/decoder/ffmpeg/a;->Q:I

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    const/4 v0, 0x1

    .line 6
    iput v0, p0, Landroidx/media3/decoder/ffmpeg/a;->Q:I

    .line 7
    .line 8
    :cond_0
    return-void
.end method

.method public final l()Ljava/lang/String;
    .locals 1

    .line 1
    const-string v0, "ExperimentalFfmpegVideoRenderer"

    .line 2
    .line 3
    return-object v0
.end method

.method public final n()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Landroidx/media3/decoder/ffmpeg/a;->S:Z

    .line 2
    .line 3
    return v0
.end method

.method public final o()Z
    .locals 9

    .line 1
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/a;->I:Lv0/t;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const-wide v2, -0x7fffffffffffffffL    # -4.9E-324

    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    if-eqz v0, :cond_2

    .line 10
    .line 11
    invoke-virtual {p0}, Ld1/a;->p()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_0

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    iget v0, p0, Landroidx/media3/decoder/ffmpeg/a;->Q:I

    .line 19
    .line 20
    const/4 v4, 0x3

    .line 21
    if-eq v0, v4, :cond_1

    .line 22
    .line 23
    iget v0, p0, Landroidx/media3/decoder/ffmpeg/a;->K:I

    .line 24
    .line 25
    const/4 v4, -0x1

    .line 26
    if-eq v0, v4, :cond_1

    .line 27
    .line 28
    goto :goto_0

    .line 29
    :cond_1
    iput-wide v2, p0, Landroidx/media3/decoder/ffmpeg/a;->R:J

    .line 30
    .line 31
    return v1

    .line 32
    :cond_2
    :goto_0
    iget-wide v4, p0, Landroidx/media3/decoder/ffmpeg/a;->R:J

    .line 33
    .line 34
    cmp-long v0, v4, v2

    .line 35
    .line 36
    const/4 v4, 0x0

    .line 37
    if-nez v0, :cond_3

    .line 38
    .line 39
    return v4

    .line 40
    :cond_3
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 41
    .line 42
    .line 43
    move-result-wide v5

    .line 44
    iget-wide v7, p0, Landroidx/media3/decoder/ffmpeg/a;->R:J

    .line 45
    .line 46
    cmp-long v0, v5, v7

    .line 47
    .line 48
    if-gez v0, :cond_4

    .line 49
    .line 50
    return v1

    .line 51
    :cond_4
    iput-wide v2, p0, Landroidx/media3/decoder/ffmpeg/a;->R:J

    .line 52
    .line 53
    return v4
.end method

.method public final q()V
    .locals 4

    .line 1
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/a;->E:Ll4/c;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    iput-object v1, p0, Landroidx/media3/decoder/ffmpeg/a;->I:Lv0/t;

    .line 5
    .line 6
    iput-object v1, p0, Landroidx/media3/decoder/ffmpeg/a;->J:Ly1/b;

    .line 7
    .line 8
    iget-object v2, p0, Landroidx/media3/decoder/ffmpeg/a;->G:Ljava/util/ArrayDeque;

    .line 9
    .line 10
    invoke-virtual {v2}, Ljava/util/ArrayDeque;->clear()V

    .line 11
    .line 12
    .line 13
    iput-object v1, p0, Landroidx/media3/decoder/ffmpeg/a;->T:Lv0/v1;

    .line 14
    .line 15
    const/4 v2, 0x0

    .line 16
    iget v3, p0, Landroidx/media3/decoder/ffmpeg/a;->Q:I

    .line 17
    .line 18
    invoke-static {v3, v2}, Ljava/lang/Math;->min(II)I

    .line 19
    .line 20
    .line 21
    move-result v2

    .line 22
    iput v2, p0, Landroidx/media3/decoder/ffmpeg/a;->Q:I

    .line 23
    .line 24
    :try_start_0
    iget-object v2, p0, Landroidx/media3/decoder/ffmpeg/a;->P:Li1/i;

    .line 25
    .line 26
    invoke-static {v2, v1}, La0/h;->E(Li1/i;Li1/i;)V

    .line 27
    .line 28
    .line 29
    iput-object v1, p0, Landroidx/media3/decoder/ffmpeg/a;->P:Li1/i;

    .line 30
    .line 31
    const/4 v1, 0x0

    .line 32
    iput v1, p0, Landroidx/media3/decoder/ffmpeg/a;->W:I

    .line 33
    .line 34
    iget-object v1, p0, Landroidx/media3/decoder/ffmpeg/a;->O:Li1/i;

    .line 35
    .line 36
    const/4 v2, 0x0

    .line 37
    invoke-static {v1, v2}, La0/h;->E(Li1/i;Li1/i;)V

    .line 38
    .line 39
    .line 40
    iput-object v2, p0, Landroidx/media3/decoder/ffmpeg/a;->O:Li1/i;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 41
    .line 42
    iget-object v1, p0, Landroidx/media3/decoder/ffmpeg/a;->X:Ld1/c;

    .line 43
    .line 44
    invoke-virtual {v0, v1}, Ll4/c;->g(Ld1/c;)V

    .line 45
    .line 46
    .line 47
    return-void

    .line 48
    :catchall_0
    move-exception v1

    .line 49
    iget-object v2, p0, Landroidx/media3/decoder/ffmpeg/a;->X:Ld1/c;

    .line 50
    .line 51
    invoke-virtual {v0, v2}, Ll4/c;->g(Ld1/c;)V

    .line 52
    .line 53
    .line 54
    throw v1
.end method

.method public final r(ZZ)V
    .locals 4

    .line 1
    new-instance p1, Ld1/c;

    .line 2
    .line 3
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Landroidx/media3/decoder/ffmpeg/a;->X:Ld1/c;

    .line 7
    .line 8
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/a;->E:Ll4/c;

    .line 9
    .line 10
    iget-object v1, v0, Ll4/c;->k:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, Landroid/os/Handler;

    .line 13
    .line 14
    if-eqz v1, :cond_0

    .line 15
    .line 16
    new-instance v2, Ly1/f0;

    .line 17
    .line 18
    const/4 v3, 0x5

    .line 19
    invoke-direct {v2, v0, p1, v3}, Ly1/f0;-><init>(Ll4/c;Ljava/lang/Object;I)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 23
    .line 24
    .line 25
    :cond_0
    iput p2, p0, Landroidx/media3/decoder/ffmpeg/a;->Q:I

    .line 26
    .line 27
    return-void
.end method

.method public final s(JZZ)V
    .locals 2

    .line 1
    const/4 p1, 0x0

    .line 2
    iput-boolean p1, p0, Landroidx/media3/decoder/ffmpeg/a;->S:Z

    .line 3
    .line 4
    iget-object p1, p0, Landroidx/media3/decoder/ffmpeg/a;->G:Ljava/util/ArrayDeque;

    .line 5
    .line 6
    invoke-virtual {p1}, Ljava/util/ArrayDeque;->isEmpty()Z

    .line 7
    .line 8
    .line 9
    move-result p2

    .line 10
    if-nez p2, :cond_0

    .line 11
    .line 12
    invoke-virtual {p1}, Ljava/util/ArrayDeque;->getLast()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p2

    .line 16
    check-cast p2, Ly1/b;

    .line 17
    .line 18
    iput-object p2, p0, Landroidx/media3/decoder/ffmpeg/a;->J:Ly1/b;

    .line 19
    .line 20
    :cond_0
    invoke-virtual {p1}, Ljava/util/ArrayDeque;->clear()V

    .line 21
    .line 22
    .line 23
    iget p1, p0, Landroidx/media3/decoder/ffmpeg/a;->Q:I

    .line 24
    .line 25
    const/4 p2, 0x1

    .line 26
    invoke-static {p1, p2}, Ljava/lang/Math;->min(II)I

    .line 27
    .line 28
    .line 29
    move-result p1

    .line 30
    iput p1, p0, Landroidx/media3/decoder/ffmpeg/a;->Q:I

    .line 31
    .line 32
    const-wide p1, -0x7fffffffffffffffL    # -4.9E-324

    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    if-eqz p3, :cond_2

    .line 38
    .line 39
    const-wide/16 p3, 0x0

    .line 40
    .line 41
    iget-wide v0, p0, Landroidx/media3/decoder/ffmpeg/a;->D:J

    .line 42
    .line 43
    cmp-long p3, v0, p3

    .line 44
    .line 45
    if-lez p3, :cond_1

    .line 46
    .line 47
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 48
    .line 49
    .line 50
    move-result-wide p1

    .line 51
    add-long/2addr p1, v0

    .line 52
    :cond_1
    iput-wide p1, p0, Landroidx/media3/decoder/ffmpeg/a;->R:J

    .line 53
    .line 54
    goto :goto_0

    .line 55
    :cond_2
    iput-wide p1, p0, Landroidx/media3/decoder/ffmpeg/a;->R:J

    .line 56
    .line 57
    :goto_0
    iget-object p1, p0, Landroidx/media3/decoder/ffmpeg/a;->F:Lo/t0;

    .line 58
    .line 59
    invoke-virtual {p1}, Lo/t0;->j()I

    .line 60
    .line 61
    .line 62
    invoke-virtual {p1}, Lo/t0;->c()V

    .line 63
    .line 64
    .line 65
    return-void
.end method

.method public final w()V
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Landroidx/media3/decoder/ffmpeg/a;->V:I

    .line 3
    .line 4
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 5
    .line 6
    .line 7
    move-result-wide v0

    .line 8
    iput-wide v0, p0, Landroidx/media3/decoder/ffmpeg/a;->U:J

    .line 9
    .line 10
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 11
    .line 12
    .line 13
    sget-object v0, Ly0/k0;->a:Ljava/lang/String;

    .line 14
    .line 15
    return-void
.end method

.method public final x()V
    .locals 8

    .line 1
    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    iput-wide v0, p0, Landroidx/media3/decoder/ffmpeg/a;->R:J

    .line 7
    .line 8
    iget v0, p0, Landroidx/media3/decoder/ffmpeg/a;->V:I

    .line 9
    .line 10
    if-lez v0, :cond_1

    .line 11
    .line 12
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 13
    .line 14
    .line 15
    move-result-wide v0

    .line 16
    iget-wide v2, p0, Landroidx/media3/decoder/ffmpeg/a;->U:J

    .line 17
    .line 18
    sub-long v2, v0, v2

    .line 19
    .line 20
    iget v4, p0, Landroidx/media3/decoder/ffmpeg/a;->V:I

    .line 21
    .line 22
    iget-object v5, p0, Landroidx/media3/decoder/ffmpeg/a;->E:Ll4/c;

    .line 23
    .line 24
    iget-object v6, v5, Ll4/c;->k:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast v6, Landroid/os/Handler;

    .line 27
    .line 28
    if-eqz v6, :cond_0

    .line 29
    .line 30
    new-instance v7, Ly1/f0;

    .line 31
    .line 32
    invoke-direct {v7, v5, v4, v2, v3}, Ly1/f0;-><init>(Ll4/c;IJ)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {v6, v7}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 36
    .line 37
    .line 38
    :cond_0
    const/4 v2, 0x0

    .line 39
    iput v2, p0, Landroidx/media3/decoder/ffmpeg/a;->V:I

    .line 40
    .line 41
    iput-wide v0, p0, Landroidx/media3/decoder/ffmpeg/a;->U:J

    .line 42
    .line 43
    :cond_1
    return-void
.end method

.method public final y([Lv0/t;JJLr1/b0;)V
    .locals 0

    .line 1
    iget-object p1, p0, Ld1/a;->s:Lr1/a1;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-interface {p1}, Lr1/a1;->b()I

    .line 7
    .line 8
    .line 9
    iget-object p1, p0, Landroidx/media3/decoder/ffmpeg/a;->J:Ly1/b;

    .line 10
    .line 11
    if-eqz p1, :cond_1

    .line 12
    .line 13
    iget-object p1, p0, Landroidx/media3/decoder/ffmpeg/a;->G:Ljava/util/ArrayDeque;

    .line 14
    .line 15
    invoke-virtual {p1}, Ljava/util/ArrayDeque;->isEmpty()Z

    .line 16
    .line 17
    .line 18
    move-result p2

    .line 19
    if-eqz p2, :cond_0

    .line 20
    .line 21
    iget p2, p0, Landroidx/media3/decoder/ffmpeg/a;->W:I

    .line 22
    .line 23
    if-nez p2, :cond_0

    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_0
    new-instance p2, Ly1/b;

    .line 27
    .line 28
    invoke-direct {p2}, Ljava/lang/Object;-><init>()V

    .line 29
    .line 30
    .line 31
    invoke-virtual {p1, p2}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    .line 32
    .line 33
    .line 34
    return-void

    .line 35
    :cond_1
    :goto_0
    new-instance p1, Ly1/b;

    .line 36
    .line 37
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 38
    .line 39
    .line 40
    iput-object p1, p0, Landroidx/media3/decoder/ffmpeg/a;->J:Ly1/b;

    .line 41
    .line 42
    return-void
.end method

.method public final z()V
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/a;->G:Ljava/util/ArrayDeque;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->isEmpty()Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    if-nez v1, :cond_0

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->getLast()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    check-cast v0, Ly1/b;

    .line 14
    .line 15
    :cond_0
    return-void
.end method
