.class public final La6/a;
.super Ljava/lang/ThreadLocal;
.source "SourceFile"


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, La6/a;->a:I

    invoke-direct {p0}, Ljava/lang/ThreadLocal;-><init>()V

    return-void
.end method


# virtual methods
.method public final initialValue()Ljava/lang/Object;
    .locals 3

    .line 1
    iget v0, p0, La6/a;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    :try_start_0
    sget-object v0, Lk6/i;->b:Lk6/i;

    .line 7
    .line 8
    const-string v1, "AES/GCM/NoPadding"

    .line 9
    .line 10
    iget-object v0, v0, Lk6/i;->a:Lk6/h;

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Lk6/h;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Ljavax/crypto/Cipher;
    :try_end_0
    .catch Ljava/security/GeneralSecurityException; {:try_start_0 .. :try_end_0} :catch_0

    .line 17
    .line 18
    return-object v0

    .line 19
    :catch_0
    move-exception v0

    .line 20
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 21
    .line 22
    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/Throwable;)V

    .line 23
    .line 24
    .line 25
    throw v1

    .line 26
    :pswitch_0
    new-instance v0, Ljava/text/SimpleDateFormat;

    .line 27
    .line 28
    const-string v1, "EEE, dd MMM yyyy HH:mm:ss \'GMT\'"

    .line 29
    .line 30
    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 31
    .line 32
    invoke-direct {v0, v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 33
    .line 34
    .line 35
    const/4 v1, 0x0

    .line 36
    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->setLenient(Z)V

    .line 37
    .line 38
    .line 39
    sget-object v1, Lp7/b;->d:Ljava/util/TimeZone;

    .line 40
    .line 41
    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    .line 42
    .line 43
    .line 44
    return-object v0

    .line 45
    :pswitch_1
    new-instance v0, Ljava/security/SecureRandom;

    .line 46
    .line 47
    invoke-direct {v0}, Ljava/security/SecureRandom;-><init>()V

    .line 48
    .line 49
    .line 50
    invoke-virtual {v0}, Ljava/util/Random;->nextLong()J

    .line 51
    .line 52
    .line 53
    return-object v0

    .line 54
    :pswitch_2
    :try_start_1
    sget-object v0, Lk6/i;->b:Lk6/i;

    .line 55
    .line 56
    const-string v1, "AES/CTR/NOPADDING"

    .line 57
    .line 58
    iget-object v0, v0, Lk6/i;->a:Lk6/h;

    .line 59
    .line 60
    invoke-virtual {v0, v1}, Lk6/h;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    check-cast v0, Ljavax/crypto/Cipher;
    :try_end_1
    .catch Ljava/security/GeneralSecurityException; {:try_start_1 .. :try_end_1} :catch_1

    .line 65
    .line 66
    return-object v0

    .line 67
    :catch_1
    move-exception v0

    .line 68
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 69
    .line 70
    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/Throwable;)V

    .line 71
    .line 72
    .line 73
    throw v1

    .line 74
    :pswitch_3
    :try_start_2
    sget-object v0, Lk6/i;->b:Lk6/i;

    .line 75
    .line 76
    const-string v1, "AES/ECB/NOPADDING"

    .line 77
    .line 78
    iget-object v0, v0, Lk6/i;->a:Lk6/h;

    .line 79
    .line 80
    invoke-virtual {v0, v1}, Lk6/h;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    check-cast v0, Ljavax/crypto/Cipher;
    :try_end_2
    .catch Ljava/security/GeneralSecurityException; {:try_start_2 .. :try_end_2} :catch_2

    .line 85
    .line 86
    return-object v0

    .line 87
    :catch_2
    move-exception v0

    .line 88
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 89
    .line 90
    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/Throwable;)V

    .line 91
    .line 92
    .line 93
    throw v1

    .line 94
    :pswitch_4
    :try_start_3
    sget-object v0, Lk6/i;->b:Lk6/i;

    .line 95
    .line 96
    const-string v1, "AES/CTR/NoPadding"

    .line 97
    .line 98
    iget-object v0, v0, Lk6/i;->a:Lk6/h;

    .line 99
    .line 100
    invoke-virtual {v0, v1}, Lk6/h;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    check-cast v0, Ljavax/crypto/Cipher;
    :try_end_3
    .catch Ljava/security/GeneralSecurityException; {:try_start_3 .. :try_end_3} :catch_3

    .line 105
    .line 106
    return-object v0

    .line 107
    :catch_3
    move-exception v0

    .line 108
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 109
    .line 110
    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/Throwable;)V

    .line 111
    .line 112
    .line 113
    throw v1

    .line 114
    :pswitch_5
    :try_start_4
    sget-object v0, Lk6/i;->b:Lk6/i;

    .line 115
    .line 116
    const-string v1, "AES/GCM-SIV/NoPadding"

    .line 117
    .line 118
    iget-object v0, v0, Lk6/i;->a:Lk6/h;

    .line 119
    .line 120
    invoke-virtual {v0, v1}, Lk6/h;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object v0

    .line 124
    check-cast v0, Ljavax/crypto/Cipher;
    :try_end_4
    .catch Ljava/security/GeneralSecurityException; {:try_start_4 .. :try_end_4} :catch_4

    .line 125
    .line 126
    return-object v0

    .line 127
    :catch_4
    move-exception v0

    .line 128
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 129
    .line 130
    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/Throwable;)V

    .line 131
    .line 132
    .line 133
    throw v1

    .line 134
    nop

    .line 135
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
