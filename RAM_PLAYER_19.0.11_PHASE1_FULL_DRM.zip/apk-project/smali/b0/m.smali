.class public final Lb0/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic k:I

.field public l:Ljava/lang/Object;

.field public m:Ljava/lang/Object;

.field public n:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>()V
    .locals 1

    .line 1
    const/4 v0, 0x0

    iput v0, p0, Lb0/m;->k:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Intent;Landroid/content/Context;Landroid/content/BroadcastReceiver$PendingResult;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, Lb0/m;->k:I

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb0/m;->l:Ljava/lang/Object;

    iput-object p2, p0, Lb0/m;->m:Ljava/lang/Object;

    iput-object p3, p0, Lb0/m;->n:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Ld4/f;Ld4/l;Lc4/r;)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, Lb0/m;->k:I

    const-string v0, "processor"

    invoke-static {p1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iput-object p1, p0, Lb0/m;->l:Ljava/lang/Object;

    .line 4
    iput-object p2, p0, Lb0/m;->m:Ljava/lang/Object;

    .line 5
    iput-object p3, p0, Lb0/m;->n:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 8

    .line 1
    iget v0, p0, Lb0/m;->k:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lb0/m;->l:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Ld4/f;

    .line 9
    .line 10
    iget-object v1, p0, Lb0/m;->m:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, Ld4/l;

    .line 13
    .line 14
    iget-object v2, p0, Lb0/m;->n:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v2, Lc4/r;

    .line 17
    .line 18
    invoke-virtual {v0, v1, v2}, Ld4/f;->j(Ld4/l;Lc4/r;)Z

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    :pswitch_0
    iget-object v0, p0, Lb0/m;->n:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v0, Landroid/content/BroadcastReceiver$PendingResult;

    .line 25
    .line 26
    iget-object v1, p0, Lb0/m;->m:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast v1, Landroid/content/Context;

    .line 29
    .line 30
    iget-object v2, p0, Lb0/m;->l:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v2, Landroid/content/Intent;

    .line 33
    .line 34
    :try_start_0
    const-string v3, "KEY_BATTERY_NOT_LOW_PROXY_ENABLED"

    .line 35
    .line 36
    const/4 v4, 0x0

    .line 37
    invoke-virtual {v2, v3, v4}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    .line 38
    .line 39
    .line 40
    move-result v3

    .line 41
    const-string v5, "KEY_BATTERY_CHARGING_PROXY_ENABLED"

    .line 42
    .line 43
    invoke-virtual {v2, v5, v4}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    .line 44
    .line 45
    .line 46
    move-result v5

    .line 47
    const-string v6, "KEY_STORAGE_NOT_LOW_PROXY_ENABLED"

    .line 48
    .line 49
    invoke-virtual {v2, v6, v4}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    .line 50
    .line 51
    .line 52
    move-result v6

    .line 53
    const-string v7, "KEY_NETWORK_STATE_PROXY_ENABLED"

    .line 54
    .line 55
    invoke-virtual {v2, v7, v4}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    .line 56
    .line 57
    .line 58
    move-result v2

    .line 59
    invoke-static {}, Lc4/q;->c()Lc4/q;

    .line 60
    .line 61
    .line 62
    move-result-object v4

    .line 63
    sget v7, Landroidx/work/impl/background/systemalarm/ConstraintProxyUpdateReceiver;->a:I

    .line 64
    .line 65
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 66
    .line 67
    .line 68
    const-class v4, Landroidx/work/impl/background/systemalarm/ConstraintProxy$BatteryNotLowProxy;

    .line 69
    .line 70
    invoke-static {v1, v4, v3}, Lm4/m;->a(Landroid/content/Context;Ljava/lang/Class;Z)V

    .line 71
    .line 72
    .line 73
    const-class v3, Landroidx/work/impl/background/systemalarm/ConstraintProxy$BatteryChargingProxy;

    .line 74
    .line 75
    invoke-static {v1, v3, v5}, Lm4/m;->a(Landroid/content/Context;Ljava/lang/Class;Z)V

    .line 76
    .line 77
    .line 78
    const-class v3, Landroidx/work/impl/background/systemalarm/ConstraintProxy$StorageNotLowProxy;

    .line 79
    .line 80
    invoke-static {v1, v3, v6}, Lm4/m;->a(Landroid/content/Context;Ljava/lang/Class;Z)V

    .line 81
    .line 82
    .line 83
    const-class v3, Landroidx/work/impl/background/systemalarm/ConstraintProxy$NetworkStateProxy;

    .line 84
    .line 85
    invoke-static {v1, v3, v2}, Lm4/m;->a(Landroid/content/Context;Ljava/lang/Class;Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 86
    .line 87
    .line 88
    invoke-virtual {v0}, Landroid/content/BroadcastReceiver$PendingResult;->finish()V

    .line 89
    .line 90
    .line 91
    return-void

    .line 92
    :catchall_0
    move-exception v1

    .line 93
    invoke-virtual {v0}, Landroid/content/BroadcastReceiver$PendingResult;->finish()V

    .line 94
    .line 95
    .line 96
    throw v1

    .line 97
    :pswitch_1
    :try_start_1
    iget-object v0, p0, Lb0/m;->l:Ljava/lang/Object;

    .line 98
    .line 99
    check-cast v0, Lb0/e;

    .line 100
    .line 101
    invoke-virtual {v0}, Lb0/e;->call()Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    move-result-object v0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 105
    goto :goto_0

    .line 106
    :catch_0
    const/4 v0, 0x0

    .line 107
    :goto_0
    iget-object v1, p0, Lb0/m;->m:Ljava/lang/Object;

    .line 108
    .line 109
    check-cast v1, Lb0/f;

    .line 110
    .line 111
    iget-object v2, p0, Lb0/m;->n:Ljava/lang/Object;

    .line 112
    .line 113
    check-cast v2, Landroid/os/Handler;

    .line 114
    .line 115
    new-instance v3, Lcom/google/common/util/concurrent/l;

    .line 116
    .line 117
    const/4 v4, 0x2

    .line 118
    invoke-direct {v3, v1, v4, v0}, Lcom/google/common/util/concurrent/l;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 119
    .line 120
    .line 121
    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 122
    .line 123
    .line 124
    return-void

    .line 125
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
