.class public final Lb5/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ls4/j;


# instance fields
.field public final synthetic a:I

.field public final b:Lv4/a;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x0

    iput v0, p0, Lb5/c;->a:I

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Lp1/h0;

    const/16 v1, 0x16

    .line 3
    invoke-direct {v0, v1}, Lp1/h0;-><init>(I)V

    .line 4
    iput-object v0, p0, Lb5/c;->b:Lv4/a;

    return-void
.end method

.method public constructor <init>(Lv4/a;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, Lb5/c;->a:I

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    iput-object p1, p0, Lb5/c;->b:Lv4/a;

    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;Ls4/h;)Z
    .locals 0

    .line 1
    iget p2, p0, Lb5/c;->a:I

    .line 2
    .line 3
    packed-switch p2, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lr4/d;

    .line 7
    .line 8
    :goto_0
    const/4 p1, 0x1

    .line 9
    return p1

    .line 10
    :pswitch_0
    invoke-static {p1}, La5/a;->w(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    goto :goto_0

    .line 14
    nop

    .line 15
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final b(Ljava/lang/Object;IILs4/h;)Lu4/y;
    .locals 1

    .line 1
    iget v0, p0, Lb5/c;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lr4/d;

    .line 7
    .line 8
    invoke-virtual {p1}, Lr4/d;->b()Landroid/graphics/Bitmap;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    iget-object p2, p0, Lb5/c;->b:Lv4/a;

    .line 13
    .line 14
    invoke-static {p1, p2}, Lb5/d;->c(Landroid/graphics/Bitmap;Lv4/a;)Lb5/d;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    return-object p1

    .line 19
    :pswitch_0
    invoke-static {p1}, La5/a;->f(Ljava/lang/Object;)Landroid/graphics/ImageDecoder$Source;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    invoke-virtual {p0, p1, p2, p3, p4}, Lb5/c;->c(Landroid/graphics/ImageDecoder$Source;IILs4/h;)Lb5/d;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    return-object p1

    .line 28
    nop

    .line 29
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public c(Landroid/graphics/ImageDecoder$Source;IILs4/h;)Lb5/d;
    .locals 1

    .line 1
    new-instance v0, La5/d;

    .line 2
    .line 3
    invoke-direct {v0, p2, p3, p4}, La5/d;-><init>(IILs4/h;)V

    .line 4
    .line 5
    .line 6
    invoke-static {p1, v0}, La5/a;->d(Landroid/graphics/ImageDecoder$Source;La5/d;)Landroid/graphics/Bitmap;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    const-string p2, "BitmapImageDecoder"

    .line 11
    .line 12
    const/4 p3, 0x2

    .line 13
    invoke-static {p2, p3}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 14
    .line 15
    .line 16
    move-result p2

    .line 17
    if-eqz p2, :cond_0

    .line 18
    .line 19
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    .line 20
    .line 21
    .line 22
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    .line 23
    .line 24
    .line 25
    :cond_0
    new-instance p2, Lb5/d;

    .line 26
    .line 27
    iget-object p3, p0, Lb5/c;->b:Lv4/a;

    .line 28
    .line 29
    check-cast p3, Lp1/h0;

    .line 30
    .line 31
    invoke-direct {p2, p1, p3}, Lb5/d;-><init>(Landroid/graphics/Bitmap;Lv4/a;)V

    .line 32
    .line 33
    .line 34
    return-object p2
.end method
