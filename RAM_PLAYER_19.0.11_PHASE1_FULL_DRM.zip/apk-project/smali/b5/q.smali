.class public final Lb5/q;
.super Lp1/h0;
.source "SourceFile"


# virtual methods
.method public final l(Landroid/graphics/Bitmap;)V
    .locals 0

    .line 1
    return-void
.end method
