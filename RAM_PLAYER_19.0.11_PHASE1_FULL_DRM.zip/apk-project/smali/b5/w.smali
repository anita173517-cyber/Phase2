.class public interface abstract Lb5/w;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract d(Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;
.end method

.method public abstract h()V
.end method

.method public abstract k()I
.end method

.method public abstract o()Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;
.end method
