.class public final La1/i0;
.super La1/n;
.source "SourceFile"
