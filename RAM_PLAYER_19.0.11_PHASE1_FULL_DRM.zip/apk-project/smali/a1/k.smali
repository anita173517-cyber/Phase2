.class public final synthetic La1/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:La1/m;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(La1/m;Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p3, p0, La1/k;->a:I

    iput-object p1, p0, La1/k;->b:La1/m;

    iput-object p2, p0, La1/k;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .locals 7

    .line 1
    iget v0, p0, La1/k;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, La1/k;->c:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Landroid/net/Uri;

    .line 9
    .line 10
    iget-object v1, p0, La1/k;->b:La1/m;

    .line 11
    .line 12
    iget-object v2, v1, La1/m;->l:Ll3/i0;

    .line 13
    .line 14
    invoke-virtual {v2}, Ll3/i0;->r()La1/i;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    iget v1, v1, La1/m;->m:I

    .line 19
    .line 20
    :try_start_0
    new-instance v3, La1/q;

    .line 21
    .line 22
    invoke-direct {v3, v0}, La1/q;-><init>(Landroid/net/Uri;)V

    .line 23
    .line 24
    .line 25
    move-object v0, v2

    .line 26
    check-cast v0, La1/r;

    .line 27
    .line 28
    invoke-virtual {v0, v3}, La1/r;->B(La1/q;)J

    .line 29
    .line 30
    .line 31
    const/16 v3, 0x400

    .line 32
    .line 33
    new-array v3, v3, [B

    .line 34
    .line 35
    const/4 v4, 0x0

    .line 36
    move v5, v4

    .line 37
    :cond_0
    :goto_0
    const/4 v6, -0x1

    .line 38
    if-eq v4, v6, :cond_2

    .line 39
    .line 40
    array-length v4, v3

    .line 41
    if-ne v5, v4, :cond_1

    .line 42
    .line 43
    array-length v4, v3

    .line 44
    mul-int/lit8 v4, v4, 0x2

    .line 45
    .line 46
    invoke-static {v3, v4}, Ljava/util/Arrays;->copyOf([BI)[B

    .line 47
    .line 48
    .line 49
    move-result-object v3

    .line 50
    :cond_1
    array-length v4, v3

    .line 51
    sub-int/2addr v4, v5

    .line 52
    invoke-virtual {v0, v3, v5, v4}, La1/r;->read([BII)I

    .line 53
    .line 54
    .line 55
    move-result v4

    .line 56
    if-eq v4, v6, :cond_0

    .line 57
    .line 58
    add-int/2addr v5, v4

    .line 59
    goto :goto_0

    .line 60
    :cond_2
    invoke-static {v3, v5}, Ljava/util/Arrays;->copyOf([BI)[B

    .line 61
    .line 62
    .line 63
    move-result-object v3

    .line 64
    array-length v4, v3

    .line 65
    invoke-static {v3, v4, v1}, La/a;->m([BII)Landroid/graphics/Bitmap;

    .line 66
    .line 67
    .line 68
    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 69
    invoke-virtual {v0}, La1/r;->close()V

    .line 70
    .line 71
    .line 72
    return-object v1

    .line 73
    :catchall_0
    move-exception v0

    .line 74
    check-cast v2, La1/r;

    .line 75
    .line 76
    invoke-virtual {v2}, La1/r;->close()V

    .line 77
    .line 78
    .line 79
    throw v0

    .line 80
    :pswitch_0
    iget-object v0, p0, La1/k;->c:Ljava/lang/Object;

    .line 81
    .line 82
    check-cast v0, [B

    .line 83
    .line 84
    array-length v1, v0

    .line 85
    iget-object v2, p0, La1/k;->b:La1/m;

    .line 86
    .line 87
    iget v2, v2, La1/m;->m:I

    .line 88
    .line 89
    invoke-static {v0, v1, v2}, La/a;->m([BII)Landroid/graphics/Bitmap;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    return-object v0

    .line 94
    nop

    .line 95
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
