.class public final La1/p;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Li3/b;


# instance fields
.field public a:I

.field public b:J

.field public c:I

.field public d:J

.field public e:Ljava/lang/Object;

.field public f:Ljava/lang/Object;

.field public g:Ljava/lang/Object;

.field public h:Ljava/lang/Object;


# direct methods
.method public constructor <init>(La2/v;La2/p0;La2/b;Ljava/lang/String;I)V
    .locals 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La1/p;->e:Ljava/lang/Object;

    .line 5
    .line 6
    iput-object p2, p0, La1/p;->f:Ljava/lang/Object;

    .line 7
    .line 8
    iput-object p3, p0, La1/p;->g:Ljava/lang/Object;

    .line 9
    .line 10
    iget p1, p3, La2/b;->a:I

    .line 11
    .line 12
    iget p2, p3, La2/b;->b:I

    .line 13
    .line 14
    iget v0, p3, La2/b;->d:I

    .line 15
    .line 16
    mul-int/2addr v0, p1

    .line 17
    div-int/lit8 v0, v0, 0x8

    .line 18
    .line 19
    iget v1, p3, La2/b;->c:I

    .line 20
    .line 21
    if-ne v1, v0, :cond_1

    .line 22
    .line 23
    mul-int v1, p2, v0

    .line 24
    .line 25
    mul-int/lit8 v2, v1, 0x8

    .line 26
    .line 27
    div-int/lit8 v1, v1, 0xa

    .line 28
    .line 29
    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    iput v0, p0, La1/p;->a:I

    .line 34
    .line 35
    new-instance v1, Lv0/s;

    .line 36
    .line 37
    invoke-direct {v1}, Lv0/s;-><init>()V

    .line 38
    .line 39
    .line 40
    const-string v3, "audio/wav"

    .line 41
    .line 42
    invoke-static {v3}, Lv0/q0;->p(Ljava/lang/String;)Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v3

    .line 46
    iput-object v3, v1, Lv0/s;->n:Ljava/lang/String;

    .line 47
    .line 48
    invoke-static {p4}, Lv0/q0;->p(Ljava/lang/String;)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object p4

    .line 52
    iput-object p4, v1, Lv0/s;->o:Ljava/lang/String;

    .line 53
    .line 54
    iput v2, v1, Lv0/s;->i:I

    .line 55
    .line 56
    iput v2, v1, Lv0/s;->j:I

    .line 57
    .line 58
    iput v0, v1, Lv0/s;->p:I

    .line 59
    .line 60
    iput p1, v1, Lv0/s;->I:I

    .line 61
    .line 62
    iget p1, p3, La2/b;->e:I

    .line 63
    .line 64
    if-nez p1, :cond_0

    .line 65
    .line 66
    const/4 p1, -0x1

    .line 67
    goto :goto_0

    .line 68
    :cond_0
    shl-int/lit8 p1, p1, 0x2

    .line 69
    .line 70
    :goto_0
    iput p1, v1, Lv0/s;->J:I

    .line 71
    .line 72
    iput p2, v1, Lv0/s;->K:I

    .line 73
    .line 74
    iput p5, v1, Lv0/s;->L:I

    .line 75
    .line 76
    new-instance p1, Lv0/t;

    .line 77
    .line 78
    invoke-direct {p1, v1}, Lv0/t;-><init>(Lv0/s;)V

    .line 79
    .line 80
    .line 81
    iput-object p1, p0, La1/p;->h:Ljava/lang/Object;

    .line 82
    .line 83
    return-void

    .line 84
    :cond_1
    new-instance p1, Ljava/lang/StringBuilder;

    .line 85
    .line 86
    const-string p2, "Expected block size: "

    .line 87
    .line 88
    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 89
    .line 90
    .line 91
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 92
    .line 93
    .line 94
    const-string p2, "; got: "

    .line 95
    .line 96
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 97
    .line 98
    .line 99
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 100
    .line 101
    .line 102
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object p1

    .line 106
    const/4 p2, 0x0

    .line 107
    invoke-static {p1, p2}, Lv0/r0;->a(Ljava/lang/String;Ljava/lang/Exception;)Lv0/r0;

    .line 108
    .line 109
    .line 110
    move-result-object p1

    .line 111
    throw p1
.end method


# virtual methods
.method public a(IJ)V
    .locals 7

    .line 1
    new-instance v0, Li3/f;

    .line 2
    .line 3
    iget-object v1, p0, La1/p;->g:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, La2/b;

    .line 6
    .line 7
    const/4 v2, 0x1

    .line 8
    int-to-long v3, p1

    .line 9
    move-wide v5, p2

    .line 10
    invoke-direct/range {v0 .. v6}, Li3/f;-><init>(La2/b;IJJ)V

    .line 11
    .line 12
    .line 13
    iget-object p1, p0, La1/p;->e:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast p1, La2/v;

    .line 16
    .line 17
    invoke-interface {p1, v0}, La2/v;->n(La2/h0;)V

    .line 18
    .line 19
    .line 20
    iget-object p1, p0, La1/p;->f:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast p1, La2/p0;

    .line 23
    .line 24
    iget-object p2, p0, La1/p;->h:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast p2, Lv0/t;

    .line 27
    .line 28
    invoke-interface {p1, p2}, La2/p0;->b(Lv0/t;)V

    .line 29
    .line 30
    .line 31
    iget-wide p2, v0, Li3/f;->e:J

    .line 32
    .line 33
    invoke-interface {p1, p2, p3}, La2/p0;->c(J)V

    .line 34
    .line 35
    .line 36
    return-void
.end method

.method public b(J)V
    .locals 0

    .line 1
    iput-wide p1, p0, La1/p;->b:J

    .line 2
    .line 3
    const/4 p1, 0x0

    .line 4
    iput p1, p0, La1/p;->c:I

    .line 5
    .line 6
    const-wide/16 p1, 0x0

    .line 7
    .line 8
    iput-wide p1, p0, La1/p;->d:J

    .line 9
    .line 10
    return-void
.end method

.method public c(La2/u;J)Z
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-wide/from16 v1, p2

    .line 4
    .line 5
    :goto_0
    const-wide/16 v3, 0x0

    .line 6
    .line 7
    cmp-long v5, v1, v3

    .line 8
    .line 9
    const/4 v6, 0x1

    .line 10
    if-lez v5, :cond_1

    .line 11
    .line 12
    iget v7, v0, La1/p;->c:I

    .line 13
    .line 14
    iget v8, v0, La1/p;->a:I

    .line 15
    .line 16
    if-ge v7, v8, :cond_1

    .line 17
    .line 18
    sub-int/2addr v8, v7

    .line 19
    int-to-long v7, v8

    .line 20
    invoke-static {v7, v8, v1, v2}, Ljava/lang/Math;->min(JJ)J

    .line 21
    .line 22
    .line 23
    move-result-wide v7

    .line 24
    long-to-int v5, v7

    .line 25
    iget-object v7, v0, La1/p;->f:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast v7, La2/p0;

    .line 28
    .line 29
    move-object/from16 v8, p1

    .line 30
    .line 31
    invoke-interface {v7, v8, v5, v6}, La2/p0;->e(Lv0/l;IZ)I

    .line 32
    .line 33
    .line 34
    move-result v5

    .line 35
    const/4 v6, -0x1

    .line 36
    if-ne v5, v6, :cond_0

    .line 37
    .line 38
    move-wide v1, v3

    .line 39
    goto :goto_0

    .line 40
    :cond_0
    iget v3, v0, La1/p;->c:I

    .line 41
    .line 42
    add-int/2addr v3, v5

    .line 43
    iput v3, v0, La1/p;->c:I

    .line 44
    .line 45
    int-to-long v3, v5

    .line 46
    sub-long/2addr v1, v3

    .line 47
    goto :goto_0

    .line 48
    :cond_1
    iget-object v1, v0, La1/p;->g:Ljava/lang/Object;

    .line 49
    .line 50
    check-cast v1, La2/b;

    .line 51
    .line 52
    iget v2, v1, La2/b;->c:I

    .line 53
    .line 54
    iget v3, v0, La1/p;->c:I

    .line 55
    .line 56
    div-int/2addr v3, v2

    .line 57
    if-lez v3, :cond_2

    .line 58
    .line 59
    iget-wide v7, v0, La1/p;->b:J

    .line 60
    .line 61
    iget-wide v9, v0, La1/p;->d:J

    .line 62
    .line 63
    iget v1, v1, La2/b;->b:I

    .line 64
    .line 65
    int-to-long v13, v1

    .line 66
    sget-object v1, Ly0/k0;->a:Ljava/lang/String;

    .line 67
    .line 68
    sget-object v15, Ljava/math/RoundingMode;->DOWN:Ljava/math/RoundingMode;

    .line 69
    .line 70
    const-wide/32 v11, 0xf4240

    .line 71
    .line 72
    .line 73
    invoke-static/range {v9 .. v15}, Ly0/k0;->d0(JJJLjava/math/RoundingMode;)J

    .line 74
    .line 75
    .line 76
    move-result-wide v9

    .line 77
    add-long v12, v7, v9

    .line 78
    .line 79
    mul-int v15, v3, v2

    .line 80
    .line 81
    iget v1, v0, La1/p;->c:I

    .line 82
    .line 83
    sub-int v16, v1, v15

    .line 84
    .line 85
    iget-object v1, v0, La1/p;->f:Ljava/lang/Object;

    .line 86
    .line 87
    move-object v11, v1

    .line 88
    check-cast v11, La2/p0;

    .line 89
    .line 90
    const/4 v14, 0x1

    .line 91
    const/16 v17, 0x0

    .line 92
    .line 93
    invoke-interface/range {v11 .. v17}, La2/p0;->f(JIIILa2/o0;)V

    .line 94
    .line 95
    .line 96
    move/from16 v1, v16

    .line 97
    .line 98
    iget-wide v7, v0, La1/p;->d:J

    .line 99
    .line 100
    int-to-long v2, v3

    .line 101
    add-long/2addr v7, v2

    .line 102
    iput-wide v7, v0, La1/p;->d:J

    .line 103
    .line 104
    iput v1, v0, La1/p;->c:I

    .line 105
    .line 106
    :cond_2
    if-gtz v5, :cond_3

    .line 107
    .line 108
    return v6

    .line 109
    :cond_3
    const/4 v1, 0x0

    .line 110
    return v1
.end method
