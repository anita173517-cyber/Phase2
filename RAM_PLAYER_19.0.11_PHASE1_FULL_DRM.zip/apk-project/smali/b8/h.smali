.class public interface abstract Lb8/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lb8/t;
.implements Ljava/nio/channels/WritableByteChannel;


# virtual methods
.method public abstract f(J)Lb8/h;
.end method

.method public abstract flush()V
.end method

.method public abstract r(Lb8/j;)Lb8/h;
.end method

.method public abstract write([B)Lb8/h;
.end method

.method public abstract writeByte(I)Lb8/h;
.end method

.method public abstract writeInt(I)Lb8/h;
.end method

.method public abstract writeShort(I)Lb8/h;
.end method

.method public abstract x(Ljava/lang/String;)Lb8/h;
.end method
