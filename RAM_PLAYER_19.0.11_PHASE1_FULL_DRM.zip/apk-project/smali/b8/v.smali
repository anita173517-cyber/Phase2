.class public interface abstract Lb8/v;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Closeable;


# virtual methods
.method public abstract b()Lb8/x;
.end method

.method public abstract d(JLb8/g;)J
.end method
